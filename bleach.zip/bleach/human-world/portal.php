<?php require_once("../internal/session.php"); ?>
<link rel="stylesheet" href="../static/style.css">
<nav><a href="dashboard.php">Dashboard</a></nav>
<div class="card"><h2>Human Investigation Portal</h2></div>
