<?php
require_once("../internal/session.php");
if(ctx()['realm']!="hollow") die("Only Hollow");
?>
<link rel="stylesheet" href="../static/style.css">
<div class="card"><h2>Las Noches</h2></div>
