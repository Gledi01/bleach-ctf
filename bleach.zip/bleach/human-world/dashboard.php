<?php
require_once("../internal/session.php");
$ctx=ctx();
if($ctx['realm']!="human") die("Denied");
?>
<link rel="stylesheet" href="../static/style.css">
<div class="card">
<h2>Dashboard</h2>
<p>Energy: <?=$ctx['energy']?></p>
<form action="upload/avatar.php" method="post" enctype="multipart/form-data">
<input type="file" name="file"><button>Upload</button>
</form>
<?php if($ctx['energy']>60){ echo "<a href='api/audit_logs.php'>Audit Logs</a>"; } ?>
</div>
