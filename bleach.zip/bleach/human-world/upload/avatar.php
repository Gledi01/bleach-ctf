<?php
require_once("../../internal/session.php");
if($_FILES){
 $tmp=$_FILES['file']['tmp_name'];
 $meta=@exif_read_data($tmp);
 if(isset($meta['COMPUTED']['UserComment'])){
  if(strpos($meta['COMPUTED']['UserComment'],"admin")!==false){
   set_ctx("energy",90);
  }
 }
 @mkdir("avatars");
 move_uploaded_file($tmp,"avatars/".rand().".jpg");
}
header("Location: ../dashboard.php");
