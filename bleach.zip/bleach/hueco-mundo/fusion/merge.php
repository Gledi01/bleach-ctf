<?php
$data=json_decode(file_get_contents("php://input"),true);
if(isset($data['weapon'])){
 echo file_get_contents("../api/internal/research.php");
}
