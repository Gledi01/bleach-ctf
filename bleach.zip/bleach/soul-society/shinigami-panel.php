<?php
require_once("../internal/session.php");
$ctx=ctx();
if($ctx['realm']!="soul") die("no");
?>
<link rel="stylesheet" href="../static/style.css">
<div class="card"><h2>Shinigami Panel</h2>
<?php if($ctx['energy']>50){ echo "<a href='api/v2/training_logs.php'>Captain Logs</a>"; } ?>
</div>
