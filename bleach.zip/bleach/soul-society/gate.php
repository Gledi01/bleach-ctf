<?php
require_once("../internal/session.php");
if(!isset($_SERVER['HTTP_X_SPIRIT_TOKEN'])) die("Token Required");
set_ctx("realm","soul");
?>
<link rel="stylesheet" href="../static/style.css">
<div class="card"><h2>Entered Soul Society</h2>
<a href="shinigami-panel.php">Open Panel</a></div>
