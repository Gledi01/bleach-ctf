<?php
require_once("../../internal/session.php");
if(ctx()['realm']!="human") die("no");
echo json_encode(["token"=>base64_encode(base64_encode("SPIRIT-CTX-HUMAN"))]);
