<?php
function layered_encode($data){
 return str_rot13(base64_encode($data));
}
