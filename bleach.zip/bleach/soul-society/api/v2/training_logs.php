<?php
$data="ZANPAKUTO_PART_1";
echo bin2hex(gzencode(base64_encode($data)));
