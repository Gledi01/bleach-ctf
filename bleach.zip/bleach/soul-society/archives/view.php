<?php
$doc=json_decode($_GET['doc'],true);
echo file_get_contents("../../".$doc['path']);
