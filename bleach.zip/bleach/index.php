<?php require_once("internal/session.php"); ?>
<link rel="stylesheet" href="static/style.css">
<nav>
 <a href="human-world/portal.php">Human World</a>
</nav>
<div class="card">
<h1>Bleach Investigation System</h1>
<p>Realm: <?=ctx()['realm']?></p>
<p>Energy: <?=ctx()['energy']?></p>
</div>
