<?php
define('IN_APP',true);
require_once("../../../config.php");
require_once("../../../internal/util.php");
$key="XORKEY123";
$raw=$key ^ FLAG_FINAL;
echo layered_encode(base64_encode($raw));
