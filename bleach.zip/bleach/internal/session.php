<?php
session_start();
if(!isset($_SESSION['ctx'])){
 $_SESSION['ctx']=[
  "realm"=>"human",
  "role"=>"guest",
  "energy"=>10,
  "artifact"=>[]
 ];
}
function ctx(){ return $_SESSION['ctx']; }
function set_ctx($k,$v){ $_SESSION['ctx'][$k]=$v; }
