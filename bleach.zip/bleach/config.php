<?php
if(!defined('IN_APP')){
 http_response_code(403);
 die("Direct access forbidden");
}
define("FLAG_FINAL","BLEACH{true_final_transcendence}");
